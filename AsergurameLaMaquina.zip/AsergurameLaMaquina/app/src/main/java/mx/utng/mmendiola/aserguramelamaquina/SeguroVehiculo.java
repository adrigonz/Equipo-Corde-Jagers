package mx.utng.mmendiola.aserguramelamaquina;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Random;

public class SeguroVehiculo extends AppCompatActivity {

    int contador = 0;

    Button btnInicio;
    Button btnFin;
    Button btnAtras;
    ImageButton btnMapa;
    ImageView imgLogo;

    LinearLayout btnAlarma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seguro_vehiculo);


        btnInicio = (Button)findViewById(R.id.btnHInicio);
        btnFin = (Button)findViewById(R.id.btnHFin);
        btnAtras = (Button)findViewById(R.id.btnAtras);
        btnAlarma = (LinearLayout)findViewById(R.id.btnAlarma);
        btnMapa = (ImageButton)findViewById(R.id.btnMapa);
        imgLogo = (ImageView)findViewById(R.id.imgLogo);

        btnInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AbrirDialogHInicio();
            }
        });

        btnFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AbrirDialogHFin();
            }
        });

        btnAlarma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivarAlarma();
            }
        });

        btnAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),UbicacionActivity.class);
                startActivityForResult(intent,0);
                //v.getContext().startActivity(intent);

            }
        });
        Random rand = new Random();
        int num = rand.nextInt(3);
        switch (num){
            case 0:
                imgLogo.setImageResource(R.drawable.carro_negro);
                break;
            case 1:
                imgLogo.setImageResource(R.drawable.carro_rojo);
                break;
            case 2:
                imgLogo.setImageResource(R.drawable.carro_verde);
                break;
        }
    }

    public String ObtenerHora(TimePicker view, int hourOfDay, int minute){
        String respuesta = "";
        contador++;
        String hora =  (hourOfDay < 10)? String.valueOf("0" + hourOfDay) : String.valueOf(hourOfDay);
        String minuto = (minute < 10)? String.valueOf("0" + minute):String.valueOf(minute);
        String horario;
        if(hourOfDay < 12) {
            horario = "a.m.";
        } else {
            horario = "p.m.";
        }
        String cadenahora = hora + ":" + minuto + " " + horario;
        Toast.makeText(this, cadenahora, Toast.LENGTH_SHORT).show();

        if(contador == 2){
            Toast.makeText(this, "2do click", Toast.LENGTH_SHORT).show();
        }
        respuesta = cadenahora;
        return respuesta;
    }

    public boolean AbrirDialogHInicio(){
        boolean respuesta = true;

        final Alarma alarma = new Alarma();

        final String horaFinal = "";
        TimePicker tpInicioAlarma;
        Button btnCancelar;
        final Button btnAceptar;
        AlertDialog.Builder builderInicio = new AlertDialog.Builder(SeguroVehiculo.this);
        View viewInicio = getLayoutInflater().inflate(R.layout.dialog_hora_inicio, null);

        builderInicio.setView(viewInicio);
        final AlertDialog dialog = builderInicio.create();
        dialog.show();

        tpInicioAlarma = (TimePicker) viewInicio.findViewById(R.id.tpInicioAlarma);
        btnAceptar = (Button) viewInicio.findViewById(R.id.btnAceptar);
        btnCancelar = (Button) viewInicio.findViewById(R.id.btnCancelar);

        tpInicioAlarma.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                alarma.setHoraInicio(ObtenerHora(view, hourOfDay, minute));
            }
        });

        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(this,"Hora final" + hora,Toast.LENGTH_SHORT).show();
                Toast.makeText(SeguroVehiculo.this, "Horal Inico " + alarma.getHoraInicio(), Toast.LENGTH_SHORT).show();
                dialog.hide();
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.hide();
            }
        });

        return respuesta;
    }

    public String AbrirDialogHFin(){
        String respuesta = "";
        TimePicker tpFinAlarma;

        AlertDialog.Builder builderFin = new AlertDialog.Builder(SeguroVehiculo.this);
        View viewFin = getLayoutInflater().inflate(R.layout.dialog_hora_fin, null);

        builderFin.setView(viewFin);
        AlertDialog dialog = builderFin.create();
        dialog.show();

        tpFinAlarma = (TimePicker) viewFin.findViewById(R.id.tpFinAlarma);

        tpFinAlarma.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                ObtenerHora(view, hourOfDay, minute);
            }
        });

        return respuesta;
    }

    public String ActivarAlarma(){
        String respuesta = "";

        int estatus = 2;

        if(estatus == 1){ // Desactivar
            Drawable shape = (Drawable) btnAlarma.getBackground();
            shape.setColorFilter(Color.parseColor("#cccccc"), android.graphics.PorterDuff.Mode.SRC);
        }else{ // Activar
            Drawable shape = (Drawable) btnAlarma.getBackground();
            shape.setColorFilter(Color.parseColor("#00cc66"), android.graphics.PorterDuff.Mode.SRC);
        }
        return respuesta;
    }
}
