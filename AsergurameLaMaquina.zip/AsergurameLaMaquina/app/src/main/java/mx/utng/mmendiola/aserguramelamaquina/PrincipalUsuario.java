package mx.utng.mmendiola.aserguramelamaquina;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.RemoteException;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;

public class PrincipalUsuario extends AppCompatActivity implements RangeNotifier, BeaconConsumer, Response.ErrorListener, Response.Listener<JSONObject> {

    protected final String TAG = PrincipalUsuario.this.getClass().getSimpleName();;
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private static final int REQUEST_ENABLE_BLUETOOTH = 1;
    private static final long DEFAULT_SCAN_PERIOD_MS = 10000l;
    //private static final long DEFAULT_SCAN_PERIOD_MS = 6000l;
    private static final String ALL_BEACONS_REGION = "AllBeaconsRegion";

    // Para interactuar con los beacons desde una actividad
    private BeaconManager mBeaconManager;

    // Representa el criterio de campos con los que buscar beacons
    private Region mRegion;
    //-----------BEACONS


    TextView img;
    TextView alert;
    TextView cocherob;
    MediaPlayer mp;
    Button btnUbicacion;

    RequestQueue requestQueue;
    JsonObjectRequest jsonObjectRequest;
    int idRep;

    int idUsuario, numMotor;
    String coord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal_usuario);

        Intent intent = getIntent();
        idUsuario = Integer.valueOf(intent.getStringExtra("idUsuario"));

        mBeaconManager = BeaconManager.getInstanceForApplication(this);

        // Fijar un protocolo beacon, Eddystone en este caso
        mBeaconManager.getBeaconParsers().add(new BeaconParser().
                setBeaconLayout(BeaconParser.EDDYSTONE_UID_LAYOUT));

        ArrayList<Identifier> identifiers = new ArrayList<>();

        mRegion = new Region(ALL_BEACONS_REGION, identifiers);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Si los permisos de localización todavía no se han concedido, solicitarlos
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED) {
                askForLocationPermissions();
            } else { // Permisos de localización concedidos
                prepareDetection();
            }
        } else { // Versiones de Android < 6
            prepareDetection();
        }
    }


        /**
         * Activar localización y bluetooth para empezar a detectar beacons
         */
        private void prepareDetection() {

            if (!isLocationEnabled()) {
                askToTurnOnLocation();
            } else { // Localización activada, comprobemos el bluetooth
                BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

                if (mBluetoothAdapter == null) {
                    showToastMessage("El telefono, no soporta esta característica");
                } else if (mBluetoothAdapter.isEnabled()) {
                    startDetectingBeacons();
                } else {

                    // Pedir al usuario que active el bluetooth
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BLUETOOTH);
                }
            }
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {

            if (requestCode == REQUEST_ENABLE_BLUETOOTH) {
                // Usuario ha activado el bluetooth
                if (resultCode == RESULT_OK) {
                    startDetectingBeacons();
                } else if (resultCode == RESULT_CANCELED) { // User refuses to enable bluetooth
                    showToastMessage("No se encontró ningún dispositivo");
                }
            }

            super.onActivityResult(requestCode, resultCode, data);
        }

        /**
         * Empezar a detectar los beacons, ocultando o mostrando los botones correspondientes
         */
        private void startDetectingBeacons() {

            // Fijar un periodo de escaneo
            mBeaconManager.setForegroundScanPeriod(DEFAULT_SCAN_PERIOD_MS);

            // Enlazar al servicio de beacons. Obtiene un callback cuando esté listo para ser usado
            mBeaconManager.bind(this);


        }

        @Override
        public void onBeaconServiceConnect() {

            try {
                // Empezar a buscar los beacons que encajen con el el objeto Región pasado, incluyendo
                // actualizaciones en la distancia estimada
                mBeaconManager.startRangingBeaconsInRegion(mRegion);

                showToastMessage("Buscando...");

            } catch (RemoteException e) {
                Log.d(TAG, "Se ha producido una excepción al empezar a buscar beacons " + e.getMessage());
            }

            mBeaconManager.addRangeNotifier(this);
        }


        /**
         * Método llamado cada DEFAULT_SCAN_PERIOD_MS segundos con los beacons detectados durante ese
         * periodo
         */
        @Override
        public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {

            if (beacons.size() == 0) {
                showToastMessage("No se detectaron beacons");
            }

            for (Beacon beacon : beacons) {
               // showToastMessage("Beacon detectado");
                Log.d("HOLA","SI ENTRO "+ beacon.getId2());

                String com;
                Identifier id = null;

                if(beacon.getId2().equals( Identifier.parse("0x000000000001")) )  {
                    Log.d("HOLA","BEACON ID: "+ beacon.getId2());
                    //Toast.makeText(this,"HOLA detecte un beacon", Toast.LENGTH_LONG).show();


                    AlertDialog.Builder mBuilder = new AlertDialog.Builder(PrincipalUsuario.this);
                    View mView = getLayoutInflater().inflate(R.layout.activity_alerta, null);

                    img = (TextView) mView.findViewById(R.id.txtimg);
                    alert = (TextView) mView.findViewById(R.id.txt_alert);
                    cocherob = (TextView) mView.findViewById(R.id.txt_cocherob);
                    mp = MediaPlayer.create(PrincipalUsuario.this, R.raw.alarma);
                    mp.start();
                    mBuilder.setView(mView);
                    AlertDialog dialog = mBuilder.create();
                    dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
                    dialog.show();


                    btnUbicacion = (Button)findViewById(R.id.btnalert);
                    btnUbicacion.setVisibility(View.VISIBLE);
                    btnUbicacion.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            LocationManager locationManager = (LocationManager)
                                    getSystemService(Context.LOCATION_SERVICE);
                            Criteria criteria = new Criteria();

                            askForLocationPermissions();

                            // Assume thisActivity is the current activity
                            int permissionCheck = ContextCompat.checkSelfPermission(PrincipalUsuario.this,
                                    Manifest.permission.ACCESS_FINE_LOCATION);
                            Location location = locationManager.getLastKnownLocation(locationManager
                                    .getBestProvider(criteria, false));
                            double latitude = location.getLatitude();
                            double longitud = location.getLongitude();

                            coord = latitude + "," + longitud;

                            ejecutaWS(idUsuario, coord);
                            /*                            stopDetectingBeacons();
                            Intent intent2 = new Intent (v.getContext(), UbicacionActivity.class);
                            startActivityForResult(intent2, 0);*/

                        }
                    });



                }else if(beacon.getId2().equals( Identifier.parse("0x000000000002")) )  {
                    Log.d("HOLA","SI ENTRO AL IF"+ beacon.getId2());
                }

                //  showToastMessage(getString(R.string.beacon_detected, beacon.getId3()));
            }
            //Toast.makeText(this, "This is my Toast message!",
                   // Toast.LENGTH_LONG).show();
        }

        private void stopDetectingBeacons() {
            try {
                mBeaconManager.stopMonitoringBeaconsInRegion(mRegion);
                showToastMessage("Dejando de buscar....");
            } catch (RemoteException e) {
                Log.d(TAG, "Se ha producido una excepción al parar de buscar beacons " + e.getMessage());
            }

            mBeaconManager.removeAllRangeNotifiers();

            // Desenlazar servicio de beacons
            mBeaconManager.unbind(this);


        }

        /**
         * Comprobar permisión de localización para Android >= M
         */
        private void askForLocationPermissions() {

            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Servicios de localización requeridos");
            builder.setMessage("Permita acceder a su localización exacta");
            builder.setPositiveButton(android.R.string.ok, null);
            builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                public void onDismiss(DialogInterface dialog) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                            PERMISSION_REQUEST_COARSE_LOCATION);
                }
            });
            builder.show();
        }

        @Override
        public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
            switch (requestCode) {
                case PERMISSION_REQUEST_COARSE_LOCATION: {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        prepareDetection();
                    } else {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setTitle("Funcionalidad limitada");
                        builder.setMessage("No se cuentan con permisos para usar la localización. No se pueden buscar beacons");
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {

                            }
                        });
                        builder.show();
                    }
                    return;
                }
            }
        }

        /**
         * Comprobar si la localización está activada
         *
         * @return true si la localización esta activada, false en caso contrario
         */
        private boolean isLocationEnabled() {

            LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

            boolean networkLocationEnabled = false;

            boolean gpsLocationEnabled = false;

            try {
                networkLocationEnabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

                gpsLocationEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);

            } catch (Exception ex) {
                Log.d(TAG, "Excepción al obtener información de localización");
            }

            return networkLocationEnabled || gpsLocationEnabled;
        }

        /**
         * Abrir ajustes de localización para que el usuario pueda activar los servicios de localización
         */
        private void askToTurnOnLocation() {

            // Notificar al usuario
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setMessage("Servicios de geolocalización no permitidos");
            dialog.setPositiveButton("Permita los servicios de geolocalización", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                    // TODO Auto-generated method stub
                    Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(myIntent);
                }
            });
            dialog.show();
        }


        /**
         * Mostrar mensaje
         *
         * @param message mensaje a enseñar
         */
        private void showToastMessage (String message) {
            Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            mBeaconManager.removeAllRangeNotifiers();
            mBeaconManager.unbind(this);
        }

    private void ejecutaWS(int usuario, String coordenadas){
        String webservice = "http://192.168.43.221/WebserviceMarcadores/ReportePosicion.php?idUsuario=" + usuario + "&ubicacion=" + coordenadas;
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, webservice,null,this,this);

        //adding request to the RequestQueue
        AppController.getInstance(this).addToRequestQueue(jsonObjectRequest);
    }

    @Override
    public void onResponse(JSONObject response) {
        try{
            JSONArray json = response.optJSONArray("reporte");
            JSONObject jsonObject = null;
            for (int i = 0; i < json.length(); i++){
                jsonObject = json.getJSONObject(i);

                //Recuperamos lo que vayas a traer en String, int o arreglo, etc.

                idRep = jsonObject.optInt("idReporte");

//                CargaPantalla(idRol, idUsuario);
                break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }



    }
    @Override
    public void onErrorResponse(VolleyError error) {
        Log.d("Error: ", error.toString());
    }


}
