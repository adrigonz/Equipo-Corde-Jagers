package mx.utng.mmendiola.aserguramelamaquina;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, Response.ErrorListener, Response.Listener<JSONObject> {

    private static final int REQUEST_ENABLE_BT = 0;
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_WIFI_STATE = 0;
    EditText etUsuario, etContrasenia;
    Button btnIngresar;
    String txtUsuario, txtContrasenia;
    String idUsuario = "";
    String idRol = "";
    String idNumMotor = "";

    RequestQueue requestQueue;
    JsonObjectRequest jsonObjectRequest;

    private void ejecutaWS(String usuario, String contraseña){
        String webservice = "http://192.168.43.221/WebserviceMarcadores/login2.php?nombreUsuario="+usuario+"&contrasenia="+contraseña;
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, webservice,null,this,this);

//       requestQueue.add(jsonObjectRequest);
        //adding request to the RequestQueue
        AppController.getInstance(this).addToRequestQueue(jsonObjectRequest);

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(getApplicationContext(), "No se pudo consultar: " + error.toString(), Toast.LENGTH_LONG).show();
        Log.d("Error: ", error.toString());
    }

    @Override
    public void onResponse(JSONObject response) {

        JSONArray json = response.optJSONArray("inicio");
        JSONObject jsonObject = null;

        try{
            for (int i = 0; i < json.length(); i++){
                jsonObject = json.getJSONObject(i);

                //Recuperamos lo que vayas a traer en String, int o arreglo, etc.


                idUsuario = jsonObject.optString("idUsuario");
                idRol = jsonObject.optString("idRol");
                idNumMotor = jsonObject.optString("idNumMotor");
                //Toast.makeText(this,"ID USUARIO" + idUsuario,Toast.LENGTH_LONG).show();
                //Toast.makeText(this,"ROL USUARIO" + idRol,Toast.LENGTH_LONG).show();

                CargaPantalla(idRol, idUsuario, idNumMotor);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }



    }


    public void CargaPantalla(String idRol, String idUsuario,String idNumMotor){
        if(idRol.equals("1")) {
            if(idNumMotor.equals("0")) {
                Intent intent = new Intent(this, IngresoCodigo.class);
                intent.putExtra("idUsuario", idUsuario);
                intent.putExtra("idRol", idRol);
                startActivity(intent);
            }
            else{
                Intent intent = new Intent(this, SeguroVehiculo.class);
                intent.putExtra("idUsuario", idUsuario);
                intent.putExtra("idRol", idRol);
                intent.putExtra("idNumMotor",idNumMotor);
                startActivity(intent);
            }
        }

        if(idRol.equals("2")){
            Intent intent = new Intent(this, PrincipalUsuario.class);
            intent.putExtra("idUsuario",idUsuario);
            intent.putExtra("idRol",idRol);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuario = (EditText)findViewById(R.id.txtUsuario);
        etContrasenia = (EditText)findViewById(R.id.txtContrasenia);
        btnIngresar = (Button)findViewById(R.id.btnIngresar);

        btnIngresar.setOnClickListener(this);

        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent,REQUEST_ENABLE_BT);

            if (!mBluetoothAdapter.isEnabled()) {

                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_WIFI_STATE},MY_PERMISSIONS_REQUEST_ACCESS_WIFI_STATE);
                if(ContextCompat.checkSelfPermission(getApplicationContext(),Manifest.permission.ACCESS_WIFI_STATE)
                        != PackageManager.PERMISSION_GRANTED){
                    finish();
                }


            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnIngresar:
                if(etUsuario.getText().toString().length() > 0){
                    if(etContrasenia.getText().toString().length() > 0){
                        txtUsuario = etUsuario.getText().toString();
                        txtContrasenia = etContrasenia.getText().toString();

                        Toast.makeText(getApplicationContext(),"Bienvenido:" + txtUsuario,Toast.LENGTH_LONG).show();



                        ejecutaWS(txtUsuario, txtContrasenia);




                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Se debe ingresar la contraseña",Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"Se debe ingresar el usuario",Toast.LENGTH_LONG).show();
                }

                //break;
        }
    }

    public String Cifrar(String cadena){

        String secretKey = "qualifyinfosolutions";
        String cadenaEncriptada = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword,24);

            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(Cipher.ENCRYPT_MODE,key);

            byte[] textoPlanoBytes = cadena.getBytes("utf-8");
            byte[] buf = cipher.doFinal(textoPlanoBytes);
            byte[] base64Bytes = Base64.encode(buf, 0);
            cadenaEncriptada = new String(base64Bytes);


        }
        catch(Exception e){
            return "0";
        }

        return cadenaEncriptada;
    }


}



