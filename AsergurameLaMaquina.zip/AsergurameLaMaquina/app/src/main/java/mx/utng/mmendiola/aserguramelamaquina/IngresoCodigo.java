package mx.utng.mmendiola.aserguramelamaquina;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class IngresoCodigo extends AppCompatActivity implements View.OnClickListener, Response.ErrorListener, Response.Listener<JSONObject>{

    EditText etCodigo;
    Button btnAceptar, btnCancelar;
    String txtCodigo;

    RequestQueue requestQueue;
    JsonObjectRequest jsonObjectRequest;
    int idUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingreso_codigo);

        etCodigo = (EditText)findViewById(R.id.txtCodigo);
        btnAceptar = (Button)findViewById(R.id.btnAceptar);
        btnCancelar = (Button)findViewById(R.id.btnCancelar);

        btnCancelar.setOnClickListener(this);
        btnAceptar.setOnClickListener(this);

        Intent intent = getIntent();
        idUsuario = Integer.valueOf(intent.getStringExtra("idUsuario"));

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnAceptar:
                Intent intent = new Intent(this,SeguroVehiculo.class);
                startActivity(intent);
                finish();
                break;
            case  R.id.btnCancelar:
                txtCodigo = etCodigo.getText().toString();
                if(txtCodigo.length() > 0){
                    etCodigo.setText("");
                    Toast.makeText(getApplicationContext(),"Vuelva a presionar el botón para salir",Toast.LENGTH_LONG).show();
                }
                else{
                    finish();
                }
                break;
        }
    }


    private void ejecutaWS(String idBluethoo){
        String webservice = "http://192.168.43.221/WebserviceMarcadores/Verificacion.php?claveBluethoo="+idBluethoo+"&idUsuario=" + idUsuario;
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, webservice,null,this,this);

        //adding request to the RequestQueue
        AppController.getInstance(this).addToRequestQueue(jsonObjectRequest);
    }

    @Override
    public void onResponse(JSONObject response) {

        JSONArray json = response.optJSONArray("clave");
        JSONObject jsonObject = null;

        try{
            for (int i = 0; i < json.length(); i++){
                jsonObject = json.getJSONObject(i);

                //Recuperamos lo que vayas a traer en String, int o arreglo, etc.

/*
                idUsuario = jsonObject.optString("idUsuario");
                idRol = jsonObject.optString("idRol");
                //Toast.makeText(this,"ID USUARIO" + idUsuario,Toast.LENGTH_LONG).show();
                //Toast.makeText(this,"ROL USUARIO" + idRol,Toast.LENGTH_LONG).show();

                CargaPantalla(idRol, idUsuario);*/

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }



    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(getApplicationContext(), "No se pudo consultar: " + error.toString(), Toast.LENGTH_LONG).show();
        Log.d("Error: ", error.toString());
    }



}
