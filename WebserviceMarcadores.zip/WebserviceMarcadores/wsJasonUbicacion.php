<?PHP
$hostname_localhost ="localhost";
$database_localhost ="seguridadhack";
$username_localhost ="root";
$password_localhost ="";

$ID = $_GET["idReporte"];

$json=array();
		$conexion = mysqli_connect($hostname_localhost,$username_localhost,$password_localhost,$database_localhost);
		$consulta="select idReporte,idUsuario,idNumMotor,ubicacion,fecha from reporte r where r.idReporte= $ID";
                
                mysqli_set_charset($conexion, "utf8");
		$resultado=mysqli_query($conexion,$consulta);
		
		while($registro=mysqli_fetch_array($resultado)){
			$result["idReporte"]=$registro['idReporte'];
			$result["idUsuario"]=$registro['idUsuario'];
                        $result["idNumMoto"]=$registro['idNumMoto'];
                        $result["ubicacion"]=$registro['ubicacion'];
                        $result["fecha"]=$registro['fecha'];
                       
			$json['reporte'][]=$result;
                }
                
		mysqli_close($conexion);
		echo json_encode($json,JSON_UNESCAPED_UNICODE);
?>