<?php
$hostname_localhost ="127.0.0.1";
$database_localhost ="seguridadhack";
$username_localhost ="root";
$password_localhost ="";

$json=array();

	 if(isset($_GET["idUsuario"]) && isset($_GET["ubicacion"])){           
             $idUsuario=$_GET['idUsuario'];
             $ubicacion=$_GET['ubicacion'];
                
             $conexion = mysqli_connect($hostname_localhost,$username_localhost,$password_localhost,$database_localhost);
             $consulta = "Select idNumMotor From usuariocoche Where idUsuario = ".$idUsuario;
             
             mysqli_set_charset($conexion, $consulta);
             echo json_encode($consulta);
             
             while ($registro = mysqli_fetch_array($resultado)){
                 $idNumMotor = $registro["idNumMotor"];
             }
              
             $insert="INSERT INTO reporte(idUsuario,idNumMotor,ubicacion) values ('{$idUsuario}','{$idNumMotor}','{$ubicacion}')";
             mysqli_set_charset($conexion, "utf8");
                
             $resultado_insert = mysqli_query($conexion,$insert);

             echo json_encode($resultado_insert);
             
             if($resultado_insert){
                 $consulta="select idReporte from reporte WHERE idUsuario ='{$idUsuario}' And idNumMotor = '{$idNumMotor}'";
                 
                 $resultado=mysqli_query($conexion,$consulta);
                 if($registro=mysqli_fetch_array($resultado)){
                     $json['reporte'][]=$registro; 
                 }
                 mysqli_close($conexion);
                 echo json_encode($json);
             }
             echo json_encode($json);
         }
         mysqli_close($conexion);
?>﻿
