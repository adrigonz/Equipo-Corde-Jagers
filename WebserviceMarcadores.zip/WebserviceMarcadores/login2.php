<?php 
$hostname_="localhost";
$database_="seguridadhack";
$username_="root";
$password_="";

if(isset($_GET["nombreUsuario"]) && isset($_GET["contrasenia"])){
$nombre_Usuario = $_GET["nombreUsuario"];
$contrasenia = $_GET["contrasenia"];

$idUsuario = 0;
$idNumMotor = 0;

/*$nombre_Usuario = "marco";
$contrasenia = "123456";*/

$json=array();

$conexion = mysqli_connect($hostname_, $username_, $password_, $database_);
$consulta = "SELECT idUsuario,idRol from usuario where nombreUsuario ='".$nombre_Usuario."' and substring(contrasenia,0,20) = substring(md5('".$contrasenia."'),0,20)";
$resultado = mysqli_query($conexion, $consulta);

while ($registro = mysqli_fetch_array($resultado)){
    $result["idUsuario"]=$registro['idUsuario'];
    $result["idRol"]=$registro['idRol'];
   
    $idUsuario = $registro['idUsuario'];
    $consulta = "Select idNumMotor from usuarioCoche where idUsuario=".$idUsuario;

    $resultCoche = mysqli_query($conexion,$consulta);
    $rows = $resultCoche->num_rows;
    if($rows > 0){
        while($reg = mysqli_fetch_array($resultCoche)){

            $result["idNumMotor"]=$reg["idNumMotor"];

        }	
    }
    else{
        $result["idNumMotor"]="0";
    }
    

    $json['inicio'][]=$result;


}

mysqli_close($conexion);
echo json_encode($json,JSON_UNESCAPED_UNICODE);
}



?>