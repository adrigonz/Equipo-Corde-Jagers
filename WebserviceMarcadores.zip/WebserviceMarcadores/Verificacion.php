<?php 
$hostname_="localhost";
$database_="seguridadhack";
$username_="root";
$password_="";

$claveBluethoo = $_GET["claveBluethoo"];
$idUsuario = $_GET['idUsuario']; 

$json=array();        
     
             $conexion = mysqli_connect($hostname_localhost,$username_localhost,$password_localhost,$database_localhost);
             $consulta = "Select idNumMotor From coche Where claveBluethoo = ".$claveBluethoo;
             
             mysqli_set_charset($conexion, $consulta);
             echo json_encode($consulta);
             
             while ($registro = mysqli_fetch_array($resultado)){
                 $idNumMotor = $registro["idNumMotor"];
             }

             if(!is_null($idNumMotor) || !($idNumMotor == 0)){
                 $insert="INSERT INTO usuariocoche(idUsuario,idNumMotor) values ('{$idUsuario}','{$idNumMotor}')";
             mysqli_set_charset($conexion, "utf8");
                
             $resultado_insert = mysqli_query($conexion,$insert);

             echo json_encode($resultado_insert);
             
             if($resultado_insert){
                 $consulta="select idUsuario from usuariocoche WHERE idUsuario ='{$idUsuario}' And idNumMotor = '{$idNumMotor}'";
                 
                 $resultado=mysqli_query($conexion,$consulta);
                 if($registro=mysqli_fetch_array($resultado)){
                     $json['clave'][]=$registro; 
                 }
                 mysqli_close($conexion);
                 echo 1;
             }
             
                 }else{
                 echo 0;
             } 
            mysqli_close($conexion);
?>