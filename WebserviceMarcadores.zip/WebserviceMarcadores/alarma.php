<?php 
$hostname_="localhost";
$database_="seguridadhack";
$username_="root";
$password_="";

$idUsuario = $_GET["idUsuario"];
$idNMotor = $_GET["idNMotor"];
$horaInicio = $_GET["horaInicio"];
$horaFin = $_GET["horaFin"];
$activo = $_GET["activo"];
$tipo = $_GET["tipo"];

$json=array();

$conexion = mysqli_connect($hostname_, $username_, $password_, $database_);

$consulta = "SELECT idAlarma, horaInicio, horaFin, activo, idUsuario, idNumMotor FROM alarma where "
        . "idUsuario = ".$idUsuario."and idNumMotor = ". $idNMotor. "";
$resultado = mysqli_query ($conexion, $consulta);
echo $consulta;
if($tipo == 1 || $tipo == 2){
    while ($registro = mysqli_fetch_array($resultado)){
        $result ["idAlarma"] = $registro["idAlarma"];
        $idAlarma = $registro["idAlarma"];
        if($result ["idAlarma"] <> 0){
            if(tipo == 1){
                $consulta = "UPDATE alarma SET horaInicio = '".$horaInicio."', horaFin = '".$horaInicio.
                "', activo = ".$activo." where idAlarma = ".$idAlarma;
            }else{
                $consulta = "UPDATE alarma SET activo = ".$activo." where idAlarma = ".$idAlarma;
            }
        }else{
            $consulta = "INSERT into alarma (horaInicio, horaFin, activo, idUsuario, idNumMotor) values"
                    . "('".$horaInicio."','".$horaFin."',".$activo.",".$idUsuario.",".$idNMotor.")";

        }
        
        $resp = $this->$conexion->prepare($consulta);
        if ($resp->execute()) {
            //true;
            $result = 1;
        } else {
            //false;
            $result = 0;
        }
        
        $json = $result;
    }
}
else{
    while ($registro = mysqli_fetch_array($resultado)){
        $result ["idAlarma"] = $registro["idAlarma"];
        $result ["horaInicio"] = $registro["horaInicio"];
        $result ["horaFin"] = $registro["horaFin"];
        $result ["activo"] = $registro["activo"];
        $result ["idUsuario"] = $registro["idUsuario"];
        $result ["idNumMotor"] = $registro["idNumMotor"];

        $json['alarma'][]=$result;   
    }    
}
mysqli_close($conexion);
echo json_encode($json);

?>

