<?php 
$hostname_="localhost";
$database_="seguridadhack";
$username_="root";
$password_="";

if(isset($_POST["nombreUsuario"]) && isset($_POST["contrasenia"])){
$nombre_Usuario = $_POST["nombreUsuario"];
$contrasenia = $_POST["contrasenia"];

$json=array();

$conexion = mysqli_connect($hostname_, $username_, $password_, $database_);
$consulta = "SELECT idUsuario,idRol from usuario where nombreUsuario ='".$nombre_Usuario."' and substring(contrasenia,0,20) = substring(md5('".$contrasenia."'),0,20)";
$resultado = mysqli_query($conexion, $consulta);

while ($registro = mysqli_fetch_array($resultado)){
    $count = $registro["idUsuario"]."|".$registro["idRol"];
}

mysqli_close($conexion);
echo $count;
}



?>